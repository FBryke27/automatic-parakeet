// test 0926
let i=0
let WRONGANS=0
let RIGHTANS=0
let DOUBLEQuestionPt1=null
let DOUBLEQuestionPt2=null
let processedAnswer = []
let firstPhaseAnswer=null
let secondPhaseAnswer=null

// FUNCTIONS DEFINED

function incrementCounter() {
    i = i + 1;
}

function wrongCounter() {
    WRONGANS=WRONGANS + 1
}

function rightCounter(){
    RIGHTANS=RIGHTANS + 1 
}

function loadChart()
{
    var chartDom = document.getElementById('ChartTarget');
    var myChart = echarts.init(chartDom);
    var option;

option = {
  title: {
    text: 'How Did You Do?',
    subtext: 'Coffee snob? Or is Earl Grey your cup of tea...',
    left: 'center'
  },
  tooltip: {
    trigger: 'item'
  },
  legend: {
    orient: 'vertical',
    left: 'center'
  },
  series: [
    {
      name: 'Access From',
      type: 'pie',
      color: [
        'rgba(255, 0, 0, 1)',
        'rgba(107, 170, 100, 1)',
      ],
      radius: '50%',
      data: [
        { value: WRONGANS, name: 'WRONG ANSWERS' },
        { value: RIGHTANS, name: 'RIGHT ANSWERS' }
      ],
      emphasis: {
        itemStyle: {
          shadowBlur: 10,
          shadowOffsetX: 0,
          shadowColor: 'rgba(0, 0, 0, 0.5)'
        }
      }
    }
  ]
};

option && myChart.setOption(option);
}

function loadFinalModal() {
  console.time('label')
  console.log('finalmodal reached')
  console.log(RIGHTANS, 'RIGHT ANSWERS AND', WRONGANS, 'WRONG ANSWERS')
  UIkit.modal('#FinalModal').show();
  UIkit.util.on(document.getElementById('FinalModal'), 'shown', loadChart)
  
  // answerreview

  if (WRONGANS == 0)
    WRONGANS = "NO";

  document.getElementById("WRONGANStarget").innerHTML = WRONGANS;
  
    if (RIGHTANS >= 10) {
      answerreview = (SOLUTIONS[13]["OverNineRight"]);

    } else if (RIGHTANS > 5) {
      answerreview = (SOLUTIONS[13]["SixToNineRight"]); 

    } else if (RIGHTANS > 2) { 
      answerreview = (SOLUTIONS[13]["ThreeToFiveRight"]); 
    }
    else
    answerreview = (SOLUTIONS[13]["UnderThreeRight"]);

document.getElementById("answerreview").innerHTML = answerreview
}



// grammarcorrect

function makeIttherightgrammar() {
  if (WRONGANS==0)
  document.getElementById("WRONGANStarget").innerText = "NO";
}
function makeIttherightgrammar() {

}

// function processesAnswer(selectedAnswer) {

//     // deals with 2 STAGE QUESTION

//     // IF THE DOUBLEQUESTION FLAG IS PRESENT
//     if (SOLUTIONS[i]['MarksDOUBLEQuestion'] == true) {
//         // AND IF PT1 IS EMPTY
//             if (DOUBLEQuestionPt1 == null) {
//         // PUT SELECTEDANSWER IN 1ST PHASE ANSWER
//         firstPhaseAnswer = selectedAnswer; 
//         } 
//         // IGNORE IF FALSE; IF PT 2 IS EMPTY
//             else if (DOUBLEQuestionPt2 == null) {
//         // PUT SELECTEDANSWER IN 2ND PHASE ANSWER
//         secondPhaseAnswer = selectedAnswer;
//         }   
//         // THEN MAKE PROCESSEDANSWER, THE OUTPUT OF THIS STAGE OF THIS 2 STAGE PROCESSING SUBFUNCTION, A LIST OF 1ST AND 2ND PHASE ANSWER
//             else {
//             let processedAnswer = firstPhaseAnswer.concat(secondPhaseAnswer);
//             // processedAnswer.push(firstPhaseAnswer);
//             // processedAnswer.join(', ');
//             // processedAnswer.push(secondPhaseAnswer);
//         }
//     } 

//     // DEALS WITH 1 STAGE QUESTION

//     if (SOLUTIONS[i]['MarksDOUBLEQuestion'] != true) {
//         processedAnswer.push(selectedAnswer);
//         processedAnswer = processedAnswer.join(', ');

//     }
// }


    // DOES THE MARKING OF THE QUESTION

    function marksQuestion(selectedAnswer) {
  console.log('marksQuestion reached')
  UIkit.modal('#MarkingModal').show();
        if
            (selectedAnswer == SOLUTIONS[i]['SOLUTION']) 
            {
            document.getElementById("MarkingModal").style.backgroundColor = "#6BAA64";
            document.getElementById("EXPLANATIONDiv").innerHTML = (SOLUTIONS[i]["RIGHT-EXPLANATION"]);
            rightCounter();
            } 
        else 
        {
            document.getElementById("MarkingModal").style.backgroundColor = "#FF0000";
            document.getElementById("EXPLANATIONDiv").innerHTML = (SOLUTIONS[i]["WRONG-EXPLANATION"]) ;
            wrongCounter();
        }
        // processedAnswer.length = 0;
        incrementCounter();
    }


function nextQuestion() {
    UIkit.modal(MarkingModal).hide()

    console.log('index is', i)
    console.log('You got', WRONGANS, 'questions wrong')
    console.log('and', RIGHTANS, 'questions right')
    loadQuestion();
    loadAnswers();
}

function loadQuestion() {
  document.getElementById("QUESTION").innerHTML = (SOLUTIONS[i]["QUESTION"]);
}

function loadAnswers() {
  document.getElementById("ANSWER A").innerHTML = (SOLUTIONS[i]["ANSWER A"]);
//   document.getElementById("ANSWER-IMAGE-A").data = (SOLUTIONS[i]["ANSWER-IMAGE-A"]);
  document.getElementById("ANSWER B").innerHTML = (SOLUTIONS[i]["ANSWER B"]);
//   document.getElementById("ANSWER-IMAGE-B").data = (SOLUTIONS[i]["ANSWER-IMAGE-B"]);
  document.getElementById("ANSWER C").innerHTML = (SOLUTIONS[i]["ANSWER C"]);
//   document.getElementById("ANSWER-IMAGE-C").data = (SOLUTIONS[i]["ANSWER-IMAGE-C"]);
  document.getElementById("ANSWER D").innerHTML = (SOLUTIONS[i]["ANSWER D"]);
//   document.getElementById("ANSWER-IMAGE-D").data = (SOLUTIONS[i]["ANSWER-IMAGE-D"]);
}

// FUNCTIONS ACTIVATED NON-SPECIFIC

    loadQuestion();
    loadAnswers();