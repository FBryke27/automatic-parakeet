// test 0926
// Questions.js

const SOLUTIONS = [
// Q1 i=0
{"ANSWER A":"WATER","ANSWER B":"COCA-COLA","ANSWER C":"TEA","ANSWER D":"BEER",

    "ANSWER-IMAGE-A": "UploadFolder/Images/Q1/Water.svg",
    "ANSWER-IMAGE-B": "UploadFolder/Images/Q1/CocaCola.svg",
    "ANSWER-IMAGE-C": "UploadFolder/Images/Q1/Tea.svg",
    "ANSWER-IMAGE-D": "UploadFolder/Images/Q1/Beer.svg",

    "SOLUTION":"ANSWER A",

    "RIGHT-EXPLANATION":"That's right- it's water. Not that we should begrude anyone the priviledge of drinking clean, safe water. Because it was dirty for most of history, tea and beer were the best ways of keeping hydrated without risking diseases.",
    "WRONG-EXPLANATION":"Not quite- it's water. Could be worse though- can you imagine how soulless it would be if we all drank Coke constantly? I guess coffee wouldn't be so bad, but no one would ever sleep.",

    "QUESTION":"Coffee is the second most drunk beverage on the planet. What is the first?"},
// Q2 i=1
{"ANSWER A":"BRAZIL","ANSWER B":"UGANDA","ANSWER C":"VIETNAM","ANSWER D":"GUATEMALA",
    
    "SOLUTION":"ANSWER A",

    "RIGHT-EXPLANATION":"That's right- Brazil churns out almost a third of the world's coffee, but it might be killing the goose that lays the golden or coffee coloured eggs. Deforestation linked to coffee cultivation took 1.8 million acres in Brazil between 2002 and 2023.",
    "WRONG-EXPLANATION":"Not quite- It's Brazil, with 30% of the world's coffee coming from the home of the Amazon rainforest. It's a contributor to deforestation globally, taking  1.8 million acres in Brazil between 2002 and 2023",

    "QUESTION":"What is the country that produces the most coffee annually?"},
// Q3 i=2
{"ANSWER A":"MADAGASCAR","ANSWER B":"INDONESIA","ANSWER C":"THAILAND","ANSWER D":"AYRSHIRE, SCOTLAND",
    
    "SOLUTION":"ANSWER B",

    "RIGHT-EXPLANATION":"That's right- Indonesia produces the most expensive coffee thanks to a small feline called the Asian Palm Civet eating, fermenting, and then excreting the beans. Takes all sorts, I guess…",
    "WRONG-EXPLANATION":"Not quite- apparantly you can get the world's cheapest coffee in Madagascar, and while a café in Ayrshire charges over £200 for a coffee to make you really think about the cost of the milk, it's Indonesia. Beans that the native Asian Palm Civets have eaten, fermented in their stomach, and excreted out become the staggeringly expensive Kopi Luwak.",

    "QUESTION":"Which of the following produces the most expensive coffee?"},
// Q4 i=3
{"ANSWER A":"ESPRESSO MARTINI","ANSWER B":"CAFÉ CORRETTO","ANSWER C":"CAFÉ BOMBÓN","ANSWER D":"BARRAQUITO",
    
    "ANSWER-IMAGE-A": "UploadFolder/Images/Q4/EspressoMartini.svg",
    "ANSWER-IMAGE-B": "UploadFolder/Images/Q4/Caffè_corretto.svg",
    "ANSWER-IMAGE-C": "UploadFolder/Images/Q4/Cafe_bombon.svg",
    "ANSWER-IMAGE-D": "UploadFolder/Images/Q4/Barraquito.svg",

    "SOLUTION":"ANSWER C",

    "RIGHT-EXPLANATION":"That's right- we're all familiar with what goes into martinis, a café corretto has either brandy, grappa, or sambuca, and the barraquito has Licor 43. Only the bombon is non-alcoholic.",
    "WRONG-EXPLANATION":"Not quite- the Bombón sounds explosive and alcoholic, but it's actually made of layers of espresso and sweetened, condensed milk.",

    "QUESTION":"Which of the following does not contain alcohol unless specified a non-alcoholic version of the drink?"},
// Q5 i=4
{"ANSWER A":"YEMEN","ANSWER B":"BAGHDAD","ANSWER C":"TEHRAN","ANSWER D":"CAIRO",
    
    "SOLUTION":"ANSWER A",

    "RIGHT-EXPLANATION":"That's right- Yemeni religious figures are believed to have used coffee to stay awake during their rituals. Very similar to college students during the ritual of deadline season. Zzzzzz….",
    "WRONG-EXPLANATION":"Not quite- although all four have their own unique coffee traditions, it's Yemen where the practice likely originated.",

    "QUESTION":"Where is the drinking of coffee believed to have originated?"},
// Q6 i=5
{"ANSWER A":"LOWER RISK OF TYPE II DIABETES","ANSWER B":"LAXATION","ANSWER C":"LOWER RISK OF PARKINSONS ","ANSWER D":"CARCINOGENIC EFFECTS",
    
    "SOLUTION":"ANSWER D",

    "RIGHT-EXPLANATION":"That's right- au contraire, in fact, since the WHO found no conclusive evidence in favour. Maybe have an iced americano though- drinking very hot drinks can lead to oesophagal cancer.",
    "WRONG-EXPLANATION":"Not quite- It's carcinogenic effects that haven't been definitely linked to coffee. Drinking very hot drinks has been linked to oesophageal cancer though, so maybe an iced americano would be a good choice.",

    "QUESTION":"Which of the following is not a scientifically confirmed result of coffee drinking?"},
// Q7 i=6
{"ANSWER A":"FIRST CRACK","ANSWER B":"SECOND CRACK","ANSWER C":"COLOUR","ANSWER D":"SECRETION OF OILS",
    
    "SOLUTION":"ANSWER B",

    "RIGHT-EXPLANATION":"That's right- roasting goes through first crack, which indicates it's becoming edible, and when it reaches second crack, it's going to be leaving that sweet spot. Or that bitter, slightly acidic spot, since this is coffee.",
    "WRONG-EXPLANATION":"Not quite- coffee's roasted til it reaches the desired point of roast, between first and second crack, in the edible zone. Before that, it's inedible, and beyond that, it's losing its 'origin character'.",

    "QUESTION":"What indicates a coffee bean has been roasted to the full extent of its natural flavours?"},
// Q8 i=7
{"ANSWER A":"USA","ANSWER B":"ITALY","ANSWER C":"TURKEY","ANSWER D":"FINLAND",
    
    "ANSWER-IMAGE-A": "UploadFolder/Images/Q8/USAcoffee.svg",
    "ANSWER-IMAGE-B": "UploadFolder/Images/Q8/ItalianCoffee.svg",
    "ANSWER-IMAGE-C": "UploadFolder/Images/Q8/Turkishcoffee.svg",
    "ANSWER-IMAGE-D": "UploadFolder/Images/Q8/FinnishKahvi.svg",
    "SOLUTION":"ANSWER D",

    "RIGHT-EXPLANATION":"That's right- Wikipedia says it's a combination of cultural ritual, I think it's to keep warm, but it's probably all those Finnish breakfasts that lead the Finns to get through between 10.8 to 12 kilos per capita, per annum",
    "WRONG-EXPLANATION":"Not quite- it's all those Finnish breakfasts (maybe). Not a country that spread coffee to the world, the Finns get through between 10.8 to 12 kilos of coffee per capita, per annum. Anything to keep warm, eh?",

    "QUESTION":"Which countries consume the most coffee per capita?"},
// Q9 i=8
{"ANSWER A":"OIL EXTRUSIONS","ANSWER B":"AFTERTASTE","ANSWER C":"ROAST FLAVOUR","ANSWER D":"BODY",
    
    "SOLUTION":"ANSWER C",

    "RIGHT-EXPLANATION":"That's right- once origin character has been replaced by roast flavour, coffee companies can't argue it's worth a king's ransom, since roasting can happen most nearly anywhere.",
    "WRONG-EXPLANATION":"Not quite- the roast flavour will overtake the origin character, and the individuality of the beans will be lost. This is what the marketing argument that pushes prices up so high rests on, so they don't want a process that can happen anywhere to be the desirable quality.",

    "QUESTION":"If roasting is carried on too long, what will the 'origin character' be replaced by?"},
// Q10 i=9
{"ANSWER A":"ARABICA","ANSWER B":"ROBUSTA","ANSWER C":"CERATONIA","ANSWER D":"LIBERICA",
    
    "ANSWER-IMAGE-A": "UploadFolder/Images/Q10/Arabica.svg",
    "ANSWER-IMAGE-B": "UploadFolder/Images/Q10/Robusta.svg",
    "ANSWER-IMAGE-C": "UploadFolder/Images/Q10/Ceratonia.svg",
    "ANSWER-IMAGE-D": "UploadFolder/Images/Q10/Liberica.svg",

    "SOLUTION":"ANSWER C",

    "RIGHT-EXPLANATION":"That's right- Ceratonia is unrelated to coffee and their fruit the carob pod can be used as a chocolate alternative- but not coffee!",
    "WRONG-EXPLANATION":"Not quite- Ceratonia is the correct answer, which is the Carob Tree, used as a chocolate alternative!",

    "QUESTION":"Which of these is not a plant cultivated for coffee production?"},
// Q11 i=10
{"ANSWER A":"1960s","ANSWER B":"1990s","ANSWER C":"2000s","ANSWER D":"1830s",
    
    "SOLUTION":"ANSWER D",

    "RIGHT-EXPLANATION":"That's right- vacuums sound too modern to be invented in the 1800s, but Johann Nörrenberg made the first one in 1827",
    "WRONG-EXPLANATION":"Not quite- vacuums were actually well known in the 1820s; this was around the time steam power was taking off, so Johann Nörrenberg was very up to date when he made the first one in 1827.",

    "QUESTION":"In which decade was the vacuum coffee maker invented?"},
// Q12 i=11
{"ANSWER A":"1901","ANSWER B":"1887","ANSWER C":"1897","ANSWER D":"1919",
    
    "SOLUTION":"ANSWER A",

    "RIGHT-EXPLANATION":"That's right- the espresso machine is kind of timeless, but I'm sure you knew that it had its 125th birthday this year!",
    "WRONG-EXPLANATION":"Not quite- it was patented in 1901. It's a timeless idea, as befits something we don't really encounter at a time of day we comprehend.",

    "QUESTION":"When was the espresso machine patented?"},
// Q13 i=12
{"ANSWER A":"RUSSIA","ANSWER B":"SPAIN","ANSWER C":"TURKEY","ANSWER D":"UKRAINE",
    
    "SOLUTION":"ANSWER D",

    "RIGHT-EXPLANATION":"That's right- it's Ukraine. Surprisingly not in the height of the Soviet Republic, the new drink was named 'red' because of the Lexus NX, and made from espresso (okay) with steamed pomegranate and orange juice. (That part's a bit weirder.)",
    "WRONG-EXPLANATION":"Not quite, but you'd think so, wouldn't you? It's actually Ukrainian. Inspired by the Lexus NX, which seems like a real meeting of worlds.",

    "QUESTION":"Where was the flat red invented?"},
// Q14 i=13
// {"ANSWER A":"MOKHA, YEMEN","ANSWER B":"MOOKA, JAPAN","ANSWER C":"OMEGNA, ITALY","ANSWER D":"ROME, ITALY",
    
//     "SOLUTION":"ANSWER A, ANSWER C",

//     "MarksDOUBLEQuestion":true,

//     "RIGHT-EXPLANATION":"Bang on! In the 1930s, Alfonso Bialetti and his son Renato made the first one in Omegna, Italy. They drew on their respective specialities of aluminium engineering and marketing, and named it after the Yemeni city of Mokha. That was a tricky one- well done! Want to see how you did overall?",
//     "WRONG-EXPLANATION":"Not quite- the Italian Alfonso Bialetti and his son Renato made the first one in Omegna, Italy in the 1930s, drawing on their respective specialities of aluminium engineering and marketing. They named it after the Yemeni city of Mokha. Ready to see how you did overall?",

//     "QUESTION":"Please select first the city where the moka pot was invented, and secondly the city it was named after."},

// FINALMODAL COMMENTS
{"OverNineRight":"You know it's just a drink right? That's all. I only know this much because I wrote the quiz. Coffee snob rating: Yes.",
    "SixToNineRight":"You clearly appreciate it, and you're a well rounded human being who can talk about this stuff, but you're not excessive about it. Coffee snob rating: Only if you're choosing to be snobby.",
    "ThreeToFiveRight":"Yeah, you know- I'm sure you'd nail a quiz on cocoa. You can do that one, not me. Coffee snob rating: You're chill.",
    "UnderThreeRight":"I don't buy it. You must have known the right answers to avoid them with such precision. Coffee snob rating: Yes."
}

]
